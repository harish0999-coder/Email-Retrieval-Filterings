import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const emails = pgTable("emails", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sender: text("sender").notNull(),
  subject: text("subject").notNull(),
  body: text("body").notNull(),
  sentDate: timestamp("sent_date").notNull(),
  processedAt: timestamp("processed_at").default(sql`now()`),
  sentiment: text("sentiment").$type<"positive" | "negative" | "neutral">(),
  sentimentScore: integer("sentiment_score"), // 1-5 scale
  priority: text("priority").$type<"urgent" | "normal" | "low">(),
  category: text("category"),
  status: text("status").$type<"pending" | "processing" | "responded" | "resolved">().default("pending"),
  extractedInfo: jsonb("extracted_info").$type<{
    contactDetails?: string[];
    issueType?: string[];
    sentimentKeywords?: string[];
    priorityKeywords?: string[];
    requirements?: string[];
  }>(),
});

export const responses = pgTable("responses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  emailId: varchar("email_id").notNull().references(() => emails.id),
  content: text("content").notNull(),
  tone: text("tone"),
  context: text("context"),
  qualityScore: integer("quality_score"), // 0-100
  isGenerated: boolean("is_generated").default(true),
  isSent: boolean("is_sent").default(false),
  generatedAt: timestamp("generated_at").default(sql`now()`),
  sentAt: timestamp("sent_at"),
});

export const analytics = pgTable("analytics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: timestamp("date").notNull().default(sql`now()`),
  totalEmails: integer("total_emails").default(0),
  urgentEmails: integer("urgent_emails").default(0),
  resolvedEmails: integer("resolved_emails").default(0),
  pendingEmails: integer("pending_emails").default(0),
  avgResponseTime: integer("avg_response_time"), // in minutes
  resolutionRate: integer("resolution_rate"), // percentage
  customerSatisfaction: integer("customer_satisfaction"), // 1-5 scale
});

export const emailsRelations = relations(emails, ({ many }) => ({
  responses: many(responses),
}));

export const responsesRelations = relations(responses, ({ one }) => ({
  email: one(emails, {
    fields: [responses.emailId],
    references: [emails.id],
  }),
}));

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertEmailSchema = createInsertSchema(emails).omit({
  id: true,
  processedAt: true,
});

export const insertResponseSchema = createInsertSchema(responses).omit({
  id: true,
  generatedAt: true,
});

export const insertAnalyticsSchema = createInsertSchema(analytics).omit({
  id: true,
  date: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Email = typeof emails.$inferSelect;
export type InsertEmail = z.infer<typeof insertEmailSchema>;
export type Response = typeof responses.$inferSelect;
export type InsertResponse = z.infer<typeof insertResponseSchema>;
export type Analytics = typeof analytics.$inferSelect;
export type InsertAnalytics = z.infer<typeof insertAnalyticsSchema>;
