import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { emailProcessor } from "./services/emailProcessor";
import { csvLoader } from "./services/csvLoader";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Load sample data on startup
  setTimeout(async () => {
    try {
      await csvLoader.loadSampleData();
    } catch (error) {
      console.error("Error loading sample data:", error);
    }
  }, 1000);

  // Get all emails with filters
  app.get("/api/emails", async (req, res) => {
    try {
      const { priority, sentiment, status, limit } = req.query;
      
      const emails = await storage.getEmailsWithFilters({
        priority: priority as string,
        sentiment: sentiment as string,
        status: status as string,
        limit: limit ? parseInt(limit as string) : undefined
      });
      
      res.json(emails);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch emails" });
    }
  });

  // Get specific email by ID
  app.get("/api/emails/:id", async (req, res) => {
    try {
      const email = await storage.getEmailById(req.params.id);
      if (!email) {
        return res.status(404).json({ error: "Email not found" });
      }
      res.json(email);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch email" });
    }
  });

  // Generate AI response for email
  app.post("/api/emails/:id/generate-response", async (req, res) => {
    try {
      const email = await storage.getEmailById(req.params.id);
      if (!email) {
        return res.status(404).json({ error: "Email not found" });
      }

      await emailProcessor.generateAIResponse(email);
      const responses = await storage.getResponsesByEmailId(email.id);
      
      res.json(responses[0]); // Return the latest response
    } catch (error) {
      console.error("Error generating response:", error);
      res.status(500).json({ error: "Failed to generate response" });
    }
  });

  // Get responses for an email
  app.get("/api/emails/:id/responses", async (req, res) => {
    try {
      const responses = await storage.getResponsesByEmailId(req.params.id);
      res.json(responses);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch responses" });
    }
  });

  // Update response content
  app.patch("/api/responses/:id", async (req, res) => {
    try {
      const { content } = req.body;
      const response = await storage.updateResponse(req.params.id, { content });
      res.json(response);
    } catch (error) {
      res.status(500).json({ error: "Failed to update response" });
    }
  });

  // Send response
  app.post("/api/responses/:id/send", async (req, res) => {
    try {
      await emailProcessor.sendResponse(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to send response" });
    }
  });

  // Mark email as resolved
  app.post("/api/emails/:id/resolve", async (req, res) => {
    try {
      await emailProcessor.markEmailAsResolved(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to resolve email" });
    }
  });

  // Get dashboard analytics
  app.get("/api/analytics", async (req, res) => {
    try {
      const analytics = await storage.getTodayAnalytics();
      res.json(analytics || {
        totalEmails: 0,
        urgentEmails: 0,
        resolvedEmails: 0,
        pendingEmails: 0,
        resolutionRate: 0
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  // Get email volume statistics
  app.get("/api/analytics/volume", async (req, res) => {
    try {
      const days = parseInt(req.query.days as string) || 7;
      const volumeStats = await storage.getEmailVolumeStats(days);
      res.json(volumeStats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch volume statistics" });
    }
  });

  // Get sentiment distribution
  app.get("/api/analytics/sentiment", async (req, res) => {
    try {
      const sentimentStats = await storage.getSentimentDistribution();
      res.json(sentimentStats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sentiment statistics" });
    }
  });

  // Process urgent emails manually
  app.post("/api/process-urgent", async (req, res) => {
    try {
      await emailProcessor.processUrgentEmails();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to process urgent emails" });
    }
  });

  // Reload sample data
  app.post("/api/reload-data", async (req, res) => {
    try {
      await csvLoader.loadSampleData();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to reload sample data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
