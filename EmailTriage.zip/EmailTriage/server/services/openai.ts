import OpenAI from "openai";
import type { Email } from "@shared/schema";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY
});

interface EmailAnalysis {
  sentiment: "positive" | "negative" | "neutral";
  sentimentScore: number; // 1-5 scale
  priority: "urgent" | "normal" | "low";
  category: string;
  extractedInfo: {
    contactDetails?: string[];
    issueType?: string[];
    sentimentKeywords?: string[];
    priorityKeywords?: string[];
    requirements?: string[];
  };
}

interface AIResponse {
  content: string;
  tone: string;
  context: string;
  qualityScore: number; // 0-100
}

export async function analyzeEmailWithAI(body: string, subject: string): Promise<EmailAnalysis> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are an expert email analysis system for customer support. Analyze the email and extract key information.

Analyze the email for:
1. Sentiment (positive/negative/neutral) and score (1-5, where 1=very negative, 5=very positive)
2. Priority (urgent/normal/low) based on keywords like "immediately", "critical", "cannot access", "urgent", "asap", "emergency", "down", "broken", "not working"
3. Category (account access, billing, technical support, general inquiry, integration, password reset, etc.)
4. Extract contact details, issue types, sentiment keywords, priority keywords, and requirements

Respond with JSON in this exact format:
{
  "sentiment": "positive|negative|neutral",
  "sentimentScore": 1-5,
  "priority": "urgent|normal|low",
  "category": "category name",
  "extractedInfo": {
    "contactDetails": ["contact info"],
    "issueType": ["issue types"],
    "sentimentKeywords": ["keywords indicating sentiment"],
    "priorityKeywords": ["keywords indicating priority"],
    "requirements": ["what the customer needs"]
  }
}`
        },
        {
          role: "user",
          content: `Subject: ${subject}\n\nBody: ${body}`
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    // Validate and sanitize the response
    return {
      sentiment: ["positive", "negative", "neutral"].includes(result.sentiment) ? result.sentiment : "neutral",
      sentimentScore: Math.max(1, Math.min(5, result.sentimentScore || 3)),
      priority: ["urgent", "normal", "low"].includes(result.priority) ? result.priority : "normal",
      category: result.category || "General Support",
      extractedInfo: {
        contactDetails: Array.isArray(result.extractedInfo?.contactDetails) ? result.extractedInfo.contactDetails : [],
        issueType: Array.isArray(result.extractedInfo?.issueType) ? result.extractedInfo.issueType : [],
        sentimentKeywords: Array.isArray(result.extractedInfo?.sentimentKeywords) ? result.extractedInfo.sentimentKeywords : [],
        priorityKeywords: Array.isArray(result.extractedInfo?.priorityKeywords) ? result.extractedInfo.priorityKeywords : [],
        requirements: Array.isArray(result.extractedInfo?.requirements) ? result.extractedInfo.requirements : []
      }
    };
  } catch (error) {
    console.error("Error analyzing email with AI:", error);
    // Fallback analysis based on keywords
    return fallbackAnalysis(body, subject);
  }
}

export async function generateResponse(email: Email): Promise<AIResponse> {
  try {
    const customerFrustration = email.sentiment === "negative" ? 
      "The customer seems frustrated, so acknowledge their frustration empathetically." : 
      email.sentiment === "positive" ? 
      "The customer has a positive tone, maintain that energy." :
      "The customer has a neutral tone, be professional and helpful.";

    const urgencyNote = email.priority === "urgent" ? 
      "This is marked as urgent - emphasize quick resolution and escalation." :
      "Handle with standard professional care.";

    const issueContext = email.extractedInfo?.issueType?.length ? 
      `The main issues are: ${email.extractedInfo.issueType.join(", ")}.` :
      "Address the general support request.";

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a professional customer support representative. Generate empathetic, helpful responses to customer emails.

Guidelines:
- Always maintain a professional and friendly tone
- Be context-aware and reference specific details from the customer's email
- Provide actionable solutions when possible
- Show empathy if the customer is frustrated
- Keep responses concise but comprehensive
- Include next steps and contact information when appropriate
- Use the customer's name if provided in the email

Respond with JSON in this format:
{
  "content": "the full email response text",
  "tone": "description of the tone used",
  "context": "brief description of the issue context",
  "qualityScore": 0-100
}`
        },
        {
          role: "user",
          content: `Generate a response for this customer email:

Subject: ${email.subject}
From: ${email.sender}
Body: ${email.body}

Additional context:
- ${customerFrustration}
- ${urgencyNote}
- ${issueContext}
- Priority: ${email.priority || "normal"}
- Category: ${email.category || "General Support"}`
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    return {
      content: result.content || generateFallbackResponse(email),
      tone: result.tone || "Professional & Empathetic",
      context: result.context || email.category || "Customer Support",
      qualityScore: Math.max(0, Math.min(100, result.qualityScore || 85))
    };
  } catch (error) {
    console.error("Error generating AI response:", error);
    return {
      content: generateFallbackResponse(email),
      tone: "Professional & Empathetic",
      context: email.category || "Customer Support",
      qualityScore: 75
    };
  }
}

function fallbackAnalysis(body: string, subject: string): EmailAnalysis {
  const text = `${subject} ${body}`.toLowerCase();
  
  // Determine priority based on keywords
  const urgentKeywords = ["urgent", "immediately", "critical", "cannot access", "asap", "emergency", "down", "broken", "not working", "help", "please"];
  const hasUrgentKeywords = urgentKeywords.some(keyword => text.includes(keyword));
  
  // Determine sentiment based on keywords
  const negativeKeywords = ["frustrated", "angry", "cannot", "not working", "broken", "error", "problem", "issue", "trouble"];
  const positiveKeywords = ["thank", "great", "good", "excellent", "appreciate", "love", "amazing"];
  
  const hasNegativeKeywords = negativeKeywords.some(keyword => text.includes(keyword));
  const hasPositiveKeywords = positiveKeywords.some(keyword => text.includes(keyword));
  
  let sentiment: "positive" | "negative" | "neutral" = "neutral";
  let sentimentScore = 3;
  
  if (hasPositiveKeywords && !hasNegativeKeywords) {
    sentiment = "positive";
    sentimentScore = 4;
  } else if (hasNegativeKeywords && !hasPositiveKeywords) {
    sentiment = "negative";
    sentimentScore = 2;
  }
  
  // Determine category
  let category = "General Support";
  if (text.includes("password") || text.includes("login") || text.includes("access")) {
    category = "Account Access";
  } else if (text.includes("billing") || text.includes("payment") || text.includes("refund")) {
    category = "Billing Support";
  } else if (text.includes("technical") || text.includes("api") || text.includes("integration")) {
    category = "Technical Support";
  }
  
  return {
    sentiment,
    sentimentScore,
    priority: hasUrgentKeywords ? "urgent" : "normal",
    category,
    extractedInfo: {
      contactDetails: [],
      issueType: [category],
      sentimentKeywords: hasNegativeKeywords ? negativeKeywords.filter(k => text.includes(k)) : [],
      priorityKeywords: hasUrgentKeywords ? urgentKeywords.filter(k => text.includes(k)) : [],
      requirements: []
    }
  };
}

function generateFallbackResponse(email: Email): string {
  const isUrgent = email.priority === "urgent";
  const isNegative = email.sentiment === "negative";
  
  let greeting = `Dear valued customer,\n\n`;
  
  if (isNegative) {
    greeting += `Thank you for reaching out, and I sincerely apologize for any inconvenience you've experienced. `;
  } else {
    greeting += `Thank you for contacting our support team. `;
  }
  
  if (isUrgent) {
    greeting += `I understand this is urgent and I'm here to help resolve this matter as quickly as possible.\n\n`;
  } else {
    greeting += `I'm here to help you with your inquiry.\n\n`;
  }
  
  let body = `I've received your message regarding "${email.subject}" and I want to ensure we address your concerns promptly.\n\n`;
  
  if (email.category === "Account Access") {
    body += `For account access issues, I recommend:\n1. Try clearing your browser cache and cookies\n2. Ensure you're using the correct email address\n3. Check if caps lock is enabled when entering your password\n\n`;
  } else if (email.category === "Billing Support") {
    body += `For billing inquiries, I'll need to review your account details. I've escalated this to our billing specialists who will reach out within 24 hours.\n\n`;
  } else {
    body += `I've reviewed your request and will work to provide you with the best solution.\n\n`;
  }
  
  let closing = `If you need immediate assistance, please don't hesitate to contact us at support@company.com or call our priority line.\n\nWe appreciate your patience and look forward to resolving this matter for you.\n\nBest regards,\nCustomer Success Team`;
  
  return greeting + body + closing;
}
