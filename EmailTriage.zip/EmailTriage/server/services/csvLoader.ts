import fs from 'fs';
import path from 'path';
import { emailProcessor } from './emailProcessor';

interface CsvEmail {
  sender: string;
  subject: string;
  body: string;
  sent_date: string;
}

export class CsvLoader {
  async loadEmailsFromCsv(csvPath: string): Promise<void> {
    try {
      const csvContent = fs.readFileSync(csvPath, 'utf-8');
      const lines = csvContent.split('\n');
      const headers = lines[0].split(',');
      
      console.log('Loading emails from CSV...');
      
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        
        const values = this.parseCsvLine(line);
        if (values.length !== headers.length) continue;
        
        const emailData: CsvEmail = {
          sender: values[0],
          subject: values[1],
          body: values[2],
          sent_date: values[3]
        };
        
        if (!emailData.sender || !emailData.subject || !emailData.body) continue;
        
        try {
          await emailProcessor.processEmail({
            sender: emailData.sender,
            subject: emailData.subject,
            body: emailData.body,
            sentDate: new Date(emailData.sent_date),
            status: "pending"
          });
          
          console.log(`Processed email from ${emailData.sender}`);
        } catch (error) {
          console.error(`Error processing email from ${emailData.sender}:`, error);
        }
      }
      
      console.log('Finished loading emails from CSV');
    } catch (error) {
      console.error('Error loading CSV file:', error);
      throw error;
    }
  }
  
  private parseCsvLine(line: string): string[] {
    const result = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    
    result.push(current.trim());
    return result;
  }
  
  async loadSampleData(): Promise<void> {
    const csvPath = path.join(process.cwd(), 'attached_assets', '68b1acd44f393_Sample_Support_Emails_Dataset (2)_1757046804158.csv');
    
    if (fs.existsSync(csvPath)) {
      await this.loadEmailsFromCsv(csvPath);
    } else {
      console.log('Sample CSV file not found, skipping data load');
    }
  }
}

export const csvLoader = new CsvLoader();
