import { storage } from "../storage";
import { analyzeEmailWithAI, generateResponse } from "./openai";
import type { Email, InsertEmail } from "@shared/schema";

export class EmailProcessor {
  async processEmail(emailData: InsertEmail): Promise<Email> {
    // Create the email record
    const email = await storage.createEmail({
      ...emailData,
      status: "processing"
    });

    try {
      // Analyze email with AI
      const analysis = await analyzeEmailWithAI(email.body, email.subject);
      
      // Update email with analysis results
      const updatedEmail = await storage.updateEmail(email.id, {
        sentiment: analysis.sentiment,
        sentimentScore: analysis.sentimentScore,
        priority: analysis.priority,
        category: analysis.category,
        extractedInfo: analysis.extractedInfo,
        status: "pending"
      });

      // Generate AI response if urgent
      if (analysis.priority === "urgent") {
        await this.generateAIResponse(updatedEmail);
      }

      // Update analytics
      await this.updateAnalytics();

      return updatedEmail;
    } catch (error) {
      console.error("Error processing email:", error);
      await storage.updateEmail(email.id, { status: "pending" });
      throw error;
    }
  }

  async generateAIResponse(email: Email): Promise<void> {
    try {
      const response = await generateResponse(email);
      
      await storage.createResponse({
        emailId: email.id,
        content: response.content,
        tone: response.tone,
        context: response.context,
        qualityScore: response.qualityScore,
        isGenerated: true,
        isSent: false
      });

      await storage.updateEmail(email.id, { status: "responded" });
    } catch (error) {
      console.error("Error generating AI response:", error);
      throw error;
    }
  }

  async processUrgentEmails(): Promise<void> {
    const urgentEmails = await storage.getEmailsByPriority("urgent");
    const pendingUrgent = urgentEmails.filter(email => email.status === "pending");

    for (const email of pendingUrgent) {
      try {
        await this.generateAIResponse(email);
      } catch (error) {
        console.error(`Error processing urgent email ${email.id}:`, error);
      }
    }
  }

  private async updateAnalytics(): Promise<void> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const allEmails = await storage.getAllEmails();
    const todayEmails = allEmails.filter(email => {
      const emailDate = new Date(email.sentDate);
      emailDate.setHours(0, 0, 0, 0);
      return emailDate.getTime() === today.getTime();
    });

    const totalEmails = todayEmails.length;
    const urgentEmails = todayEmails.filter(email => email.priority === "urgent").length;
    const resolvedEmails = todayEmails.filter(email => email.status === "resolved").length;
    const pendingEmails = todayEmails.filter(email => email.status === "pending").length;

    const resolutionRate = totalEmails > 0 ? Math.round((resolvedEmails / totalEmails) * 100) : 0;

    await storage.createOrUpdateAnalytics({
      totalEmails,
      urgentEmails,
      resolvedEmails,
      pendingEmails,
      resolutionRate
    });
  }

  async markEmailAsResolved(emailId: string): Promise<void> {
    await storage.updateEmail(emailId, { status: "resolved" });
    await this.updateAnalytics();
  }

  async sendResponse(responseId: string): Promise<void> {
    const response = await storage.updateResponse(responseId, {
      isSent: true,
      sentAt: new Date()
    });

    if (response.emailId) {
      await storage.updateEmail(response.emailId, { status: "resolved" });
      await this.updateAnalytics();
    }
  }
}

export const emailProcessor = new EmailProcessor();
