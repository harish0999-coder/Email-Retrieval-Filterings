import { type User, type InsertUser, type Email, type InsertEmail, type Response, type InsertResponse, type Analytics, emails, responses, analytics, users } from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, sql, count } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Emails
  getAllEmails(): Promise<Email[]>;
  getEmailById(id: string): Promise<Email | undefined>;
  getEmailsByStatus(status: string): Promise<Email[]>;
  getEmailsByPriority(priority: string): Promise<Email[]>;
  getEmailsBySentiment(sentiment: string): Promise<Email[]>;
  createEmail(email: InsertEmail): Promise<Email>;
  updateEmail(id: string, updates: Partial<Email>): Promise<Email>;
  getEmailsWithFilters(filters: {
    priority?: string;
    sentiment?: string;
    status?: string;
    limit?: number;
  }): Promise<Email[]>;

  // Responses
  getResponsesByEmailId(emailId: string): Promise<Response[]>;
  createResponse(response: InsertResponse): Promise<Response>;
  updateResponse(id: string, updates: Partial<Response>): Promise<Response>;

  // Analytics
  getTodayAnalytics(): Promise<Analytics | undefined>;
  getAnalyticsByDateRange(startDate: Date, endDate: Date): Promise<Analytics[]>;
  createOrUpdateAnalytics(analytics: Partial<Analytics>): Promise<Analytics>;
  getEmailVolumeStats(days: number): Promise<{ date: string; count: number }[]>;
  getSentimentDistribution(): Promise<{ sentiment: string; count: number }[]>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Emails
  async getAllEmails(): Promise<Email[]> {
    return await db.select().from(emails).orderBy(desc(emails.sentDate));
  }

  async getEmailById(id: string): Promise<Email | undefined> {
    const [email] = await db.select().from(emails).where(eq(emails.id, id));
    return email || undefined;
  }

  async getEmailsByStatus(status: string): Promise<Email[]> {
    return await db.select().from(emails).where(eq(emails.status, status as any)).orderBy(desc(emails.sentDate));
  }

  async getEmailsByPriority(priority: string): Promise<Email[]> {
    return await db.select().from(emails).where(eq(emails.priority, priority as any)).orderBy(desc(emails.sentDate));
  }

  async getEmailsBySentiment(sentiment: string): Promise<Email[]> {
    return await db.select().from(emails).where(eq(emails.sentiment, sentiment as any)).orderBy(desc(emails.sentDate));
  }

  async createEmail(email: InsertEmail): Promise<Email> {
    const [newEmail] = await db
      .insert(emails)
      .values({
        ...email,
        status: (email.status || "pending") as "pending" | "processing" | "responded" | "resolved"
      })
      .returning();
    return newEmail;
  }

  async updateEmail(id: string, updates: Partial<Email>): Promise<Email> {
    const [updatedEmail] = await db
      .update(emails)
      .set(updates)
      .where(eq(emails.id, id))
      .returning();
    return updatedEmail;
  }

  async getEmailsWithFilters(filters: {
    priority?: string;
    sentiment?: string;
    status?: string;
    limit?: number;
  }): Promise<Email[]> {
    const conditions = [];
    if (filters.priority) {
      conditions.push(eq(emails.priority, filters.priority as any));
    }
    if (filters.sentiment) {
      conditions.push(eq(emails.sentiment, filters.sentiment as any));
    }
    if (filters.status) {
      conditions.push(eq(emails.status, filters.status as any));
    }
    
    let baseQuery = db.select().from(emails);
    
    if (conditions.length > 0) {
      baseQuery = baseQuery.where(and(...conditions));
    }
    
    baseQuery = baseQuery.orderBy(desc(emails.sentDate));
    
    if (filters.limit) {
      baseQuery = baseQuery.limit(filters.limit);
    }
    
    return await baseQuery;
  }

  // Responses
  async getResponsesByEmailId(emailId: string): Promise<Response[]> {
    return await db.select().from(responses).where(eq(responses.emailId, emailId)).orderBy(desc(responses.generatedAt));
  }

  async createResponse(response: InsertResponse): Promise<Response> {
    const [newResponse] = await db
      .insert(responses)
      .values(response)
      .returning();
    return newResponse;
  }

  async updateResponse(id: string, updates: Partial<Response>): Promise<Response> {
    const [updatedResponse] = await db
      .update(responses)
      .set(updates)
      .where(eq(responses.id, id))
      .returning();
    return updatedResponse;
  }

  // Analytics
  async getTodayAnalytics(): Promise<Analytics | undefined> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const [analytic] = await db.select().from(analytics).where(gte(analytics.date, today));
    return analytic || undefined;
  }

  async getAnalyticsByDateRange(startDate: Date, endDate: Date): Promise<Analytics[]> {
    return await db.select().from(analytics)
      .where(and(gte(analytics.date, startDate), gte(analytics.date, endDate)))
      .orderBy(desc(analytics.date));
  }

  async createOrUpdateAnalytics(analyticsData: Partial<Analytics>): Promise<Analytics> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const [existing] = await db.select().from(analytics).where(gte(analytics.date, today));
    
    if (existing) {
      const [updated] = await db
        .update(analytics)
        .set(analyticsData)
        .where(eq(analytics.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(analytics)
        .values({ ...analyticsData, date: today })
        .returning();
      return created;
    }
  }

  async getEmailVolumeStats(days: number): Promise<{ date: string; count: number }[]> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    const result = await db
      .select({
        date: sql<string>`DATE(${emails.sentDate})`,
        count: count()
      })
      .from(emails)
      .where(gte(emails.sentDate, startDate))
      .groupBy(sql`DATE(${emails.sentDate})`)
      .orderBy(sql`DATE(${emails.sentDate})`);
    
    return result;
  }

  async getSentimentDistribution(): Promise<{ sentiment: string; count: number }[]> {
    const result = await db
      .select({
        sentiment: emails.sentiment,
        count: count()
      })
      .from(emails)
      .where(sql`${emails.sentiment} IS NOT NULL`)
      .groupBy(emails.sentiment);
    
    return result.map(r => ({ sentiment: r.sentiment || 'unknown', count: r.count }));
  }
}

export const storage = new DatabaseStorage();
