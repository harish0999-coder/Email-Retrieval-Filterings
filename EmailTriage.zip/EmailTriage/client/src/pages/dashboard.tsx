import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import EmailListPanel from "@/components/EmailListPanel";
import EmailDetailPanel from "@/components/EmailDetailPanel";
import AnalyticsPanel from "@/components/AnalyticsPanel";
import type { Email, Analytics } from "@shared/schema";

export default function Dashboard() {
  const [selectedEmailId, setSelectedEmailId] = useState<string | null>(null);
  const [filters, setFilters] = useState({
    priority: "",
    sentiment: "",
    status: ""
  });
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const { data: emails = [], isLoading: emailsLoading, refetch: refetchEmails } = useQuery({
    queryKey: ["/api/emails", filters.priority, filters.sentiment, filters.status],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters.priority && filters.priority !== "all") params.append("priority", filters.priority);
      if (filters.sentiment && filters.sentiment !== "all") params.append("sentiment", filters.sentiment);
      if (filters.status && filters.status !== "all") params.append("status", filters.status);
      
      const response = await fetch(`/api/emails?${params}`);
      if (!response.ok) throw new Error("Failed to fetch emails");
      return response.json() as Promise<Email[]>;
    },
  });

  const { data: analytics } = useQuery({
    queryKey: ["/api/analytics"],
    queryFn: async () => {
      const response = await fetch(`/api/analytics`);
      if (!response.ok) throw new Error("Failed to fetch analytics");
      return response.json() as Promise<Analytics>;
    },
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const selectedEmail = emails.find(email => email.id === selectedEmailId);

  const handleEmailSelect = (emailId: string) => {
    setSelectedEmailId(emailId);
  };

  const handleFiltersChange = (newFilters: typeof filters) => {
    setFilters(newFilters);
  };

  const handleSyncEmails = async () => {
    await refetchEmails();
  };

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <Sidebar 
        isMobileMenuOpen={isMobileMenuOpen}
        onMobileMenuClose={() => setIsMobileMenuOpen(false)}
        onFilterChange={(filter) => {
          setFilters({
            priority: filter.priority || "",
            sentiment: filter.sentiment || "",
            status: filter.status || ""
          });
        }}
        currentFilters={filters}
      />
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <Header 
          totalEmails={analytics?.totalEmails || 0}
          onMobileMenuToggle={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          onSyncEmails={handleSyncEmails}
        />
        
        {/* Dashboard Content */}
        <div className="flex-1 overflow-hidden">
          <div className="h-full flex">
            {/* Email List Panel */}
            <EmailListPanel
              emails={emails}
              selectedEmailId={selectedEmailId}
              onEmailSelect={handleEmailSelect}
              filters={filters}
              onFiltersChange={handleFiltersChange}
              analytics={analytics}
              isLoading={emailsLoading}
            />
            
            {/* Main Content Area */}
            <div className="flex-1 flex flex-col">
              {/* Email Detail Panel */}
              <EmailDetailPanel
                email={selectedEmail}
                onEmailUpdate={refetchEmails}
              />
              
              {/* Analytics Panel */}
              <AnalyticsPanel />
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="lg:hidden fixed inset-0 z-50 bg-background/80 backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
          data-testid="mobile-menu-overlay"
        >
          <div className="fixed inset-y-0 left-0 w-64 bg-card border-r border-border">
            <Sidebar 
              isMobileMenuOpen={true}
              onMobileMenuClose={() => setIsMobileMenuOpen(false)}
              onFilterChange={(filter) => {
          setFilters({
            priority: filter.priority || "",
            sentiment: filter.sentiment || "",
            status: filter.status || ""
          });
        }}
              currentFilters={filters}
            />
          </div>
        </div>
      )}
    </div>
  );
}
